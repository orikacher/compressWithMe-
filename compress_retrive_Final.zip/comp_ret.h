#pragma once
class comp_ret
{
private:
public:
	comp_ret();
	int CompFile(char* fileBC, char* fileAC);
	int RetFile(char* fileAC, char* fileBC);
	char anlyz(char comLet);
	
};

