#include "comp_ret.h"
#include<iostream>
#include<cstdlib>
#include<fstream>
using namespace std;

void main()
{
	comp_ret com;
	
	char FileBC[50], FileAC[50];
	cout << "enter the name of the file you want to compress : " << endl;
	cin.getline(FileBC, 50);

	cout << "enter file name after compressing : " << endl;
	cin.getline(FileAC, 50);
	
	com.CompFile(FileBC, FileAC);
	
	cout << "enter the file name you want to decompress : " << endl;
	cin.getline(FileBC, 50);

	cout << "enter file name after retriving : " << endl;
	cin.getline(FileAC, 50);

	com.RetFile(FileAC, FileBC);

	system("pause");
}