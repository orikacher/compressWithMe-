#include "comp_ret.h"
#include<cstdlib>
#include<iostream>
#include<fstream>

using namespace std;

comp_ret::comp_ret()
{

}

int comp_ret::CompFile(char* fileBC, char* fileAC)
{

	ifstream fileIn;
	ofstream fileOut;
	char temp = 0x00, current = 0x00;
	int counter = 0;
	fileIn.open(fileBC);
	fileOut.open(fileAC);


	if (!fileIn.is_open())
	{
		return 0;
	}
	if (!fileOut.is_open())
	{
		return 0;
	}


	while (fileIn.get(current))
	{
		counter++;

		switch (current)
		{
		case 'a': temp = temp | 0x00;
			break;
		case 'b': temp = temp | 0x01;
			break;
		case 'c': temp = temp | 0x02;
			break;
		case 'd': temp = temp | 0x03;
			break;
		case 'e': temp = temp | 0x04;
			break;
		case 'f': temp = temp | 0x05;
			break;
		case 'g': temp = temp | 0x06;
			break;
		case 'h': temp = temp | 0x07;
			break;
		default:
			break;
		}

		if (counter % 2 == 0)
		{
			fileOut << temp;
			temp = 0x00;
		}
		else
		{
			temp = temp << 4;
		}
	}

	if (counter % 2 != 0)
	{
			temp = temp | 0x0F;
			fileOut << temp;
		}

	}
int comp_ret::RetFile(char* fileA, char* fileB)
{
	ifstream fileIn;
	ofstream fileOut;
	char left = 0x00, right = 0x00, current;
	int counter = 0;
	fileIn.open(fileB);
	fileOut.open(fileA);


	if (!fileIn.is_open())
	{
		return 0;
	}
	if (!fileOut.is_open())
	{
		return 0;
	}


	while (fileIn.get(current))
	{

		right = current & 0x0f;
		left = (current >> 4) & 0x0f;
		fileOut << anlyz(left);
		fileOut << anlyz(right);
	}



}
char comp_ret::anlyz(char comChar)
{
		switch (comChar)
		{
		case 0x00: return 'a';
		case 0x01: return 'b';
		case 0x02: return 'c';
		case 0x03: return 'd';
		case 0x04: return 'e';
		case 0x05: return 'f';
		case 0x06: return 'g';
		case 0x07: return 'h';
		default:
			return '#';
		}
		return '#';
}
